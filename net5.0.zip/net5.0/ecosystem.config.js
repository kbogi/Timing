module.exports = {
  apps : [{
    script: 'Race.exe',
    watch: '.'
  }],
};
